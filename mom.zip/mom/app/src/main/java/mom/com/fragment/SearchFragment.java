package mom.com.fragment;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import org.greenrobot.eventbus.Subscribe;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import mom.com.activities.BaseActivity;
import mom.com.activities.BaseFragment;
import mom.com.adapter.HomeFragmentAdapter;
import mom.com.adapter.SearchAdapter;
import mom.com.helper.FusedLocation;
import mom.com.model.HomeModel3;
import mom.com.R;
import mom.com.network.ApiCallService;
import mom.com.network.response.MomListResponse;
import mom.com.network.response.MomListResponse2;

public class SearchFragment extends BaseFragment {
    RecyclerView recyclerView;
    EditText search;
    MomListResponse2 response;
    SearchAdapter searchAdapter;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_search, container, false);
        ((AppCompatActivity) getActivity()).getSupportActionBar().setTitle("Search");
        recyclerView = view.findViewById(R.id.recyclerView);
        search=view.findViewById(R.id.search);

        Map map=new HashMap();
        try {
            map.put("latitude", FusedLocation.location.getLongitude());
            map.put("longitude", FusedLocation.location.getLongitude());
        }catch (Exception e){
            map.put("latitude", "");
            map.put("longitude", "");
        }
        ApiCallService.action(getActivity(),map,ApiCallService.Action.ACTION_MOM_LIST2);


        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                try {
                    SearchAdapter.filteredList = response.getVendor_data();
                    SearchAdapter.responseList = response.getVendor_data();
                    searchAdapter.getFilter().filter(s.toString());
                } catch (Exception e) {

                }

            }
        });
        return  view;

    }




    @Subscribe
    public void getMomList(MomListResponse2 response){
        this.response=response;
        Toast.makeText(getContext(), "hi", Toast.LENGTH_SHORT).show();
        setAdapter(response);
    }


    void setAdapter(MomListResponse2 response){
        recyclerView.setLayoutManager(new GridLayoutManager(getContext(),2));
        searchAdapter = new SearchAdapter(response.getVendor_data(),getActivity());
        recyclerView.setAdapter(searchAdapter);
        recyclerView.setFocusable(false);
    }

}
