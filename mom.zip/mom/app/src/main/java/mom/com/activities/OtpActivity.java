package mom.com.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.goodiebag.pinview.Pinview;
import com.google.firebase.FirebaseApp;
import com.google.firebase.iid.FirebaseInstanceId;

import org.greenrobot.eventbus.Subscribe;

import java.util.HashMap;
import java.util.Map;

import mom.com.R;
import mom.com.network.ApiCallService;
import mom.com.network.response.LoginSignUpMainResponse;
import mom.com.network.response.LoginSignUpResponse;
import mom.com.network.response.SucessResponse;
import mom.com.network.response.TokenResponse;
import mom.com.utils.AppUser;
import mom.com.utils.Preferences;

public class OtpActivity extends BaseActivity {

    Button submit;
    String from;
    String otp;
    Pinview pinView;
    TextView mobile;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FirebaseApp.initializeApp(this);
        setContentView(R.layout.activity_otp);
        submit=findViewById(R.id.submit);
        pinView=findViewById(R.id.pinView);
        mobile=findViewById(R.id.mobile);
//        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
//        getSupportActionBar().setTitle("Verify Mobile Number");
        mobile.setText(getIntent().getStringExtra("mobile"));

        from=getIntent().getStringExtra("from");
        otp=getIntent().getStringExtra("otp");
        Map map=new HashMap();
        map.put("mobile",getIntent().getStringExtra("mobile"));
        map.put("fcmToken",FirebaseInstanceId.getInstance().getToken());
        ApiCallService.action2(OtpActivity.this,map,ApiCallService.Action.ACTION_SEND_TOKEN);

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (pinView.getValue().isEmpty()){
                    getDialog("Please enter opt");
                    return;
                }if (pinView.getValue().length()!=4){
                    getDialog("Please enter complete opt");
                    return;
                }if (!pinView.getValue().equals(otp)){
                    getDialog("Invalid Otp");
                    return;
                }
                if (from.equals("signUp")){
                    ApiCallService.action(OtpActivity.this, AppUser.getAppUser().getSignUpRequest(),ApiCallService.Action.ACTION_SIGN_UP);
                }else {
                    ApiCallService.action(OtpActivity.this, AppUser.getAppUser().getLoginRequest(),ApiCallService.Action.ACTION_SIGN_IN);
                }


            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        finish();
        return super.onOptionsItemSelected(item);
    }


    @Subscribe
    public void loginSignUp(LoginSignUpMainResponse response){
        if (response.getResponse().getConfirmation()==1) {
            Preferences.getInstance(getApplicationContext()).setLogin(true);
            Preferences.getInstance(getApplicationContext()).setName(response.getResponse().getName());
            Preferences.getInstance(getApplicationContext()).setEmail(response.getResponse().getEmail());
            Preferences.getInstance(getApplicationContext()).setMobile(response.getResponse().getMobile());
            Preferences.getInstance(getApplicationContext()).setApiKey(response.getResponse().getApi_key());

            Preferences.getInstance(getApplicationContext()).setAddress(response.getResponse().getAddress());
            Preferences.getInstance(getApplicationContext()).setLatitude(response.getResponse().getLatitude());
            Preferences.getInstance(getApplicationContext()).setLongitude(response.getResponse().getLongitude());
            Preferences.getInstance(getApplicationContext()).setAddressStatus(response.getResponse().getAddressStatus());
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
        }else {
            getDialog(response.getResponse().getMessage());
        }
    }



 @Subscribe
    public void tokenResponse(TokenResponse response){
        if (response.getResponse().getConfirmation()==1) {
//            Toast.makeText(this, ""+response.getResponse().getMessage(), Toast.LENGTH_SHORT).show();
        }else {
            getDialog(response.getResponse().getMessage());
        }
    }




}
