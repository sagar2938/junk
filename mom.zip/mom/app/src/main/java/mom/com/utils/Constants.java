package mom.com.utils;

public interface Constants {

    String PRODUCTION_URL = "https://mom-apicall.appspot.com/";
    String STAGING_ULR = "https://mom-apicall.appspot.com/" ;
    String TESTING_URL  = "https://mom-apicall.appspot.com/" ;
    String BASE_URL = PRODUCTION_URL;
}
