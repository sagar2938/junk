package mom.com.fragment;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import org.greenrobot.eventbus.Subscribe;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import mom.com.activities.BaseFragment;
import mom.com.adapter.HomeFragmentAdapter;
import mom.com.adapter.HomeHorizontalAdapter;
import mom.com.adapter.OfferHorizontalAdapter;
import mom.com.helper.FusedLocation;
import mom.com.model.HomeModel;
import mom.com.R;
import mom.com.network.ApiCallService;
import mom.com.network.response.MomListResponse;

public class HomeFragment extends BaseFragment {
    RecyclerView recyclerView;
    RecyclerView recyclerViewOffer;
    EditText search;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.home_fragment, container, false);
        ((AppCompatActivity) getActivity()).getSupportActionBar().setTitle("Home");
        recyclerView = view.findViewById(R.id.recyclerView);
        recyclerViewOffer = view.findViewById(R.id.recyclerViewOffer);
        search=view.findViewById(R.id.search);

        Map map=new HashMap();
        try {
            map.put("latitude", FusedLocation.location.getLongitude());
            map.put("longitude", FusedLocation.location.getLongitude());
        }catch (Exception e){
            map.put("latitude", "");
            map.put("longitude", "");
        }

        ApiCallService.action(getActivity(),map,ApiCallService.Action.ACTION_MOM_LIST);

        return  view;

    }
    
    
    @Subscribe
    public void getMomList(MomListResponse response){
        Toast.makeText(getContext(), "hi", Toast.LENGTH_SHORT).show();
        setAdapter(response);
    }


    void setAdapter(MomListResponse response){
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setAdapter(new HomeFragmentAdapter(response,getContext()));
        recyclerView.setFocusable(false);


        recyclerViewOffer.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false));
        recyclerViewOffer.setAdapter(new OfferHorizontalAdapter(response.getOffer(),getContext()));
        recyclerViewOffer.setFocusable(false);

    }
}
