package mom.com.network.response;

public class LoginSignUpMainResponse {
    LoginSignUpResponse response;

    public LoginSignUpResponse getResponse() {
        return response;
    }

    public void setResponse(LoginSignUpResponse response) {
        this.response = response;
    }
}
