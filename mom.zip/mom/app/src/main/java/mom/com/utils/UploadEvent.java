package mom.com.utils;

public class UploadEvent {
    String url;
    public UploadEvent(String url){
        this.url=url;
    }

    public String getUrl() {
        return url;
    }
}
