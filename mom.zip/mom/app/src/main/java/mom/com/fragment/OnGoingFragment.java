package mom.com.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import mom.com.activity.ProfileActivity;
import mom.com.R;

public class OnGoingFragment extends Fragment {
    RecyclerView recyclerView;
    RelativeLayout cart;
    ImageView cartImg;
    LinearLayout cartLayout;

    RelativeLayout payment;
    ImageView paymentImg;
    LinearLayout paymentLayout;

    RelativeLayout order;
    ImageView orderImg;
    LinearLayout orderLayout;

    RelativeLayout other;
    ImageView otherImg;
    LinearLayout otherLayout;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_ongoing, container, false);

/*
        cart=view.findViewById(R.id.cart);
        cartImg=view.findViewById(R.id.cartImg);
        cartLayout=view.findViewById(R.id.cartLayout);

        payment=view.findViewById(R.id.payment);
        paymentImg=view.findViewById(R.id.paymentImg);
        paymentLayout=view.findViewById(R.id.paymentLayout);

        order=view.findViewById(R.id.order);
        orderImg=view.findViewById(R.id.orderImg);
        orderLayout=view.findViewById(R.id.orderLayout);


        other=view.findViewById(R.id.other);
        otherImg=view.findViewById(R.id.otherImg);
        otherLayout=view.findViewById(R.id.otherLayout);

        cart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (cartLayout.getVisibility()==View.VISIBLE){
                    cartImg.setRotation(90);
                    cartLayout.setVisibility(View.GONE);
                }else {
                    cartLayout.setVisibility(View.VISIBLE);
                    cartImg.setRotation(270);
                }
            }
        });

        payment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (paymentLayout.getVisibility()==View.VISIBLE){
                    paymentImg.setRotation(90);
                    paymentLayout.setVisibility(View.GONE);
                }else {
                    paymentLayout.setVisibility(View.VISIBLE);
                    paymentImg.setRotation(270);
                }
            }
        });

        order.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (orderLayout.getVisibility()==View.VISIBLE){
                    orderImg.setRotation(90);
                    orderLayout.setVisibility(View.GONE);
                }else {
                    orderLayout.setVisibility(View.VISIBLE);
                    orderImg.setRotation(270);
                }
            }
        });

        other.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (otherLayout.getVisibility()==View.VISIBLE){
                    otherImg.setRotation(90);
                    otherLayout.setVisibility(View.GONE);
                }else {
                    otherLayout.setVisibility(View.VISIBLE);
                    otherImg.setRotation(270);
                }
            }
        });
*/


        return  view;

    }

}
