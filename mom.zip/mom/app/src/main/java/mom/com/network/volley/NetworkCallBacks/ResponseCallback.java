package mom.com.network.volley.NetworkCallBacks;

import org.json.JSONObject;

/**
 * Created by silence12 on 25/7/17.
 */

public interface ResponseCallback {
    void OnSuccessFull(JSONObject Response);
}
