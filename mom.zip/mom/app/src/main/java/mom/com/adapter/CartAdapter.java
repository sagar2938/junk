package mom.com.adapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

import mom.com.R;
import mom.com.activities.CartActivity;
import mom.com.model.CartModel;

public class CartAdapter extends RecyclerView.Adapter<CartAdapter.ViewHolder> {
    List<CartModel> cartModelList;
    CartActivity context;

    public CartAdapter(List<CartModel> cartModelList, CartActivity context) {
        this.cartModelList = cartModelList;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.row_cart, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder viewHolder, int position) {

        CartModel cartModel = cartModelList.get(position);

        viewHolder.itemName.setText(cartModel.getItemName());
        viewHolder.itemActualPrice.setText("₹" + cartModel.getItemActualPrice());
        viewHolder.type.setText(cartModel.getType());
        viewHolder.price.setText("" + cartModel.getPrice());
        viewHolder.quantity.setText("" + cartModel.getQuantity());


        viewHolder.plus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cartModel.setQuantity(cartModel.getQuantity() + 1);
                cartModel.setPrice(cartModel.getPrice() + Double.valueOf(cartModel.getItemActualPrice()));
                addOnNotify(MomItemDetailAdapter.context, cartModel);
                notifyDataSetChanged();
            }
        });


        viewHolder.minus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (cartModel.getQuantity() == 1) {
                    if (cartModelList.size() == 1) {
                        context.getDialog("You can't remove");
                        return;
                    }
                    cartModelList.remove(position);
//                    MomItemDetailAdapter.context.mPrice.remove(cartModel.getId());
                } else {
                    cartModel.setQuantity(cartModel.getQuantity() - 1);
                    cartModel.setPrice(cartModel.getPrice() - Double.valueOf(cartModel.getItemActualPrice()));
                }
                removeOnNotify(MomItemDetailAdapter.context, cartModel);
                notifyDataSetChanged();
            }
        });


    }

    void removeOnNotify(MomItemDetailAdapter context, CartModel cartModel) {

        context.mPrice.put(cartModel.getId(), (context.mPrice.get(cartModel.getId()) - Double.valueOf(cartModel.getItemActualPrice())));
        context.mQuantityState.put(cartModel.getId(), ""+(Integer.valueOf(context.mQuantityState.get(cartModel.getId()))- 1));
        if (cartModel.getType().equals("Quarter")) {
            if (context.mQuarterQuantity.get(cartModel.getId()) != null) {
                if (context.mQuarterQuantity.get(cartModel.getId()) == 1) {
                    context.mQuarterQuantity.remove(cartModel.getId());
                } else {
                    context.mQuarterQuantity.put(cartModel.getId(), (context.mQuarterQuantity.get(cartModel.getId()) - 1));
                }
            }
        } else if (cartModel.getType().equals("Half")) {
            if (context.mHalfQuantity.get(cartModel.getId()) != null) {
                if (context.mHalfQuantity.get(cartModel.getId()) == 1) {
                    context.mHalfQuantity.remove(cartModel.getId());
                } else {
                    context.mHalfQuantity.put(cartModel.getId(), (context.mHalfQuantity.get(cartModel.getId()) - 1));
                }
            }
        } else if (cartModel.getType().equals("Full")) {
            if (context.mFullQuantity.get(cartModel.getId()) != null) {
                if (context.mFullQuantity.get(cartModel.getId()) == 1) {
                    context.mFullQuantity.remove(cartModel.getId());
                } else {
                    context.mFullQuantity.put(cartModel.getId(), (context.mFullQuantity.get(cartModel.getId()) - 1));
                }
            }
        }
        setCartMainPrice("remove",cartModel.getItemActualPrice());
    }

    void addOnNotify(MomItemDetailAdapter context, CartModel cartModel) {
        context.mPrice.put(cartModel.getId(), (context.mPrice.get(cartModel.getId()) + Double.valueOf(cartModel.getItemActualPrice())));
        context.mQuantityState.put(cartModel.getId(), "" + (Integer.valueOf(context.mQuantityState.get(cartModel.getId())) + 1));
        if (cartModel.getType().equals("Quarter")) {
            context.mQuarterQuantity.put(cartModel.getId(), (context.mQuarterQuantity.get(cartModel.getId()) + 1));
        } else if (cartModel.getType().equals("Half")) {
            context.mHalfQuantity.put(cartModel.getId(), (context.mHalfQuantity.get(cartModel.getId()) + 1));
        } else if (cartModel.getType().equals("Full")) {
            context.mFullQuantity.put(cartModel.getId(), (context.mFullQuantity.get(cartModel.getId()) + 1));
        }
        setCartMainPrice("add",cartModel.getItemActualPrice());
    }


    @Override
    public int getItemCount() {
        return cartModelList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView itemName;
        TextView itemActualPrice;
        TextView type;
        TextView price;
        TextView quantity;
        TextView minus;
        TextView plus;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            itemName = itemView.findViewById(R.id.itemName);
            itemActualPrice = itemView.findViewById(R.id.itemActualPrice);
            type = itemView.findViewById(R.id.type);
            price = itemView.findViewById(R.id.price);
            quantity = itemView.findViewById(R.id.quantity);
            minus = itemView.findViewById(R.id.minus);
            plus = itemView.findViewById(R.id.plus);

        }
    }


    void  setCartMainPrice(String operation,String amount){
        MomItemDetailAdapter.context.setMainPrice(operation,amount);
        if (operation.equals("add")){
            CartActivity.context.setAmount((CartActivity.context.getAmount()+Double.valueOf(amount)));
        }else {
            CartActivity.context.setAmount((CartActivity.context.getAmount()-Double.valueOf(amount)));
        }
    }
}
