package mom.com.network.volley.NetworkCallBacks;

/**
 * Created by silence12 on 13/10/17.
 */

public interface ServiceCallBacks {
    void OnSuccess();
}
