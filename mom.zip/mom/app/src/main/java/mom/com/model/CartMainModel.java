package mom.com.model;

import java.util.ArrayList;
import java.util.List;

public class CartMainModel {

    String name;
    String location;
    String latitude;
    String longitude;
    String mom_mobile;
    String mobile;
    String total_price;
    String paymentMode;
    List<CartModel> product_list=new ArrayList<>();

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getMom_mobile() {
        return mom_mobile;
    }

    public void setMom_mobile(String mom_mobile) {
        this.mom_mobile = mom_mobile;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getTotal_price() {
        return total_price;
    }

    public void setTotal_price(String total_price) {
        this.total_price = total_price;
    }

    public List<CartModel> getProduct_list() {
        return product_list;
    }

    public void setProduct_list(List<CartModel> product_list) {
        this.product_list = product_list;
    }

    public String getPaymentMode() {
        return paymentMode;
    }

    public void setPaymentMode(String paymentMode) {
        this.paymentMode = paymentMode;
    }
}
