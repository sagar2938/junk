package mom.com.utils;


import java.util.Map;

public class AppUser {

    static AppUser appUser;
    public static AppUser getInstance(){
        if (AppUser.appUser==null){
            appUser=new AppUser();
        }
        return appUser;
    }


    public static AppUser getAppUser() {
        return appUser;
    }

    public static void setAppUser(AppUser appUser) {
        AppUser.appUser = appUser;
    }

    Map signUpRequest;
    Map loginRequest;

    public Map getSignUpRequest() {
        return signUpRequest;
    }

    public void setSignUpRequest(Map signUpRequest) {
        this.signUpRequest = signUpRequest;
    }

    public Map getLoginRequest() {
        return loginRequest;
    }

    public void setLoginRequest(Map loginRequest) {
        this.loginRequest = loginRequest;
    }
}
