package mom.com.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.constraint.ConstraintLayout;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import mom.com.activities.CartActivity;
import mom.com.activities.HomePageActivity;
import mom.com.activities.LoginActivity;
import mom.com.activity.ProfileActivity;
import mom.com.bookmark.BookmarkActivity;
import mom.com.cartpage.AddDeliveryActivty;
import mom.com.favorite.FavoriteActivity;
import mom.com.R;
import mom.com.otherpages.NotificationsActivity;
import mom.com.utils.Preferences;

public class MenuFragment extends Fragment {
    CardView loginSignUp;
    CardView profile;
    RelativeLayout bookmark, notifications, logout;
    LinearLayout your_orders, favorite_orders, adress_book;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_menu, container, false);
        ((AppCompatActivity) getActivity()).getSupportActionBar().setTitle("Menu");




        profile = view.findViewById(R.id.profile);
        loginSignUp = view.findViewById(R.id.loginSignUp);
        bookmark = view.findViewById(R.id.bookmark);
        notifications = view.findViewById(R.id.notifications);
        your_orders = view.findViewById(R.id.your_orders);
        favorite_orders = view.findViewById(R.id.favorite_orders);
        adress_book = view.findViewById(R.id.adress_book);
        logout = view.findViewById(R.id.logout);

        profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //startActivity(new Intent(getActivity(), EditProfileActivity.class));

                startActivity(new Intent(getActivity(), ProfileActivity.class));
            }
        });

        loginSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //startActivity(new Intent(getActivity(), EditProfileActivity.class));

                startActivity(new Intent(getActivity(), HomePageActivity.class));
            }
        });


        if (Preferences.getInstance(getContext()).isLogin()) {
            loginSignUp.setVisibility(View.GONE);
        } else {
            profile.setVisibility(View.GONE);
            logout.setVisibility(View.GONE);
        }


        bookmark.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), BookmarkActivity.class);
                startActivity(intent);
            }
        });

        notifications.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), NotificationsActivity.class);
                startActivity(intent);
            }
        });
        your_orders.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), CartActivity.class);
                startActivity(intent);
            }
        });
        favorite_orders.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), FavoriteActivity.class);
                startActivity(intent);
            }
        });

        adress_book.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), AddDeliveryActivty.class);
                startActivity(intent);
            }
        });

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Preferences.getInstance(getActivity()).setLogin(false);
                Intent intent = new Intent(getActivity(), LoginActivity.class);
                startActivity(intent);
            }
        });
        return view;

    }

}
