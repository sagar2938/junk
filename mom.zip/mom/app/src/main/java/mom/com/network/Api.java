package mom.com.network;

import java.util.Map;

import mom.com.model.CartMainModel;
import mom.com.network.response.LoginSignUpMainResponse;
import mom.com.network.response.LoginSignUpResponse;
import mom.com.network.response.MomListResponse;
import mom.com.network.response.MomListResponse2;
import mom.com.network.response.MomsItemListResponse;
import mom.com.network.response.OrderBookingResponse;
import mom.com.network.response.SucessResponse;
import mom.com.network.response.TokenResponse;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface Api {

    @POST("/api/user/login/")
    Call<LoginSignUpMainResponse> login(@Body Map signUp);

    @POST("/api/add/user/")
    Call<LoginSignUpMainResponse> signUp(@Body Map signUp);


    @POST("/api/customer/send/otp/")
    Call<SucessResponse> resendOtp(@Body Map signUp);


    @POST("/api/customer/check/auth/")
    Call<SucessResponse> sendOtp(@Body Map signUp);

    @POST("/api/customer/addtoken/")
    Call<TokenResponse> sendToken(@Body Map signUp);

    @POST("/api/get/vendor/list/")
    Call<MomListResponse> getMomList(@Body Map signUp);

    @POST("/api/get/vendor/list/")
    Call<MomListResponse2> getMomList2(@Body Map signUp);

    @POST("/api/get/menu/list/")
    Call<MomsItemListResponse> getMenu(@Body Map map);

    @POST("/api/add/order/list/")
    Call<OrderBookingResponse> submitOrder(@Body CartMainModel cartMainModel);

    @POST("/api/update/user/address/")
    Call<SucessResponse> addAddress(@Body Map address);

}
