package mom.com.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.greenrobot.eventbus.Subscribe;

import java.util.HashMap;
import java.util.Map;

import mom.com.R;
import mom.com.network.ApiCallService;
import mom.com.network.response.SucessResponse;
import mom.com.utils.AppUser;
import mom.com.utils.Helper;

public class LoginActivity extends BaseActivity {

    EditText mobile;
    Button submit;
    String otp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        mobile=findViewById(R.id.mobile);
        submit=findViewById(R.id.submit);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mobile.getText().toString().isEmpty()){
                    getDialog("Enter mobile number");
                    return;
                } if (mobile.getText().toString().length()!=10){
                    getDialog("Enter valid mobile number");
                    return;
                }
                otp= Helper.getOtp();
                Map map=new HashMap();
                map.put("mobile",mobile.getText().toString());
                map.put("otp",otp);
                map.put("referal_code","");
                AppUser.getInstance().getAppUser().setLoginRequest(map);
                ApiCallService.action(LoginActivity.this,map,ApiCallService.Action.ACTION_SEND_OTP);
            }
        });

    }


    @Subscribe
    public void getOtp(SucessResponse response){
        if (response.getResponse().getConfirmation()==1) {
            Toast.makeText(this, "" + otp, Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(getApplicationContext(), OtpActivity.class);
            intent.putExtra("from", "login");
            intent.putExtra("otp", otp);
            intent.putExtra("mobile", mobile.getText().toString());
            startActivity(intent);
        }else {
            getDialog(response.getResponse().getMessage());
        }
    }
}
