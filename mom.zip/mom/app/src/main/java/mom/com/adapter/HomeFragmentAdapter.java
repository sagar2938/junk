package mom.com.adapter;

import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.support.annotation.NonNull;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions;
import com.bumptech.glide.request.RequestOptions;

import java.util.List;

import mom.com.R;
import mom.com.activities.MomItemDetailActivity;
import mom.com.helper.FusedLocation;
import mom.com.network.response.MomListResponse;
import mom.com.network.response.VendorData;

public class HomeFragmentAdapter extends RecyclerView.Adapter<HomeFragmentAdapter.ViewHolder> {
    MomListResponse response;
    Context context;

    public HomeFragmentAdapter(MomListResponse response, Context context) {
        this.response=response;
        this.context=context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view= LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.row_mom_list,viewGroup,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder viewHolder, int position) {

        VendorData vendorData=response.getVendor_data().get(position);
        Glide.with(context)
                .load(vendorData.getPimagePath()+vendorData.getProfileImage())
                .transition(DrawableTransitionOptions.withCrossFade())
                .apply(RequestOptions.skipMemoryCacheOf(true))
                .apply(RequestOptions.diskCacheStrategyOf(DiskCacheStrategy.ALL))
                .apply(new RequestOptions().placeholder(R.drawable.default_food))
                .into(viewHolder.momImage);

        viewHolder.momTittle.setText(vendorData.getName());
        viewHolder.rating.setText(vendorData.getRating());
        viewHolder.address.setText(vendorData.getHouseNo()+" "+vendorData.getLocality()+" "+vendorData.getCity());
        try {

            Integer minute=Integer.valueOf(vendorData.getEstimateTime().toString());

            int day=minute/24/60;
            int hour=minute/60%24;
            int min=minute%60;


            if (day==0){
                if (hour==0){
                    viewHolder.time.setText(""+min+" Min");
                }else {
                    viewHolder.time.setText(hour +" Hour "+min+" Min");

                }
            }else {
                viewHolder.time.setText(day+" Day "+hour +" Hour "+min+" Min");
            }


        }catch (Exception e){
            viewHolder.time.setText("");
        }

        viewHolder.mainLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(context, MomItemDetailActivity.class);
                intent.putExtra("mobile",vendorData.getMobile());
                intent.putExtra("name",vendorData.getName());
                intent.putExtra("rating",vendorData.getRating());
                intent.putExtra("address",viewHolder.address.getText().toString());
                intent.putExtra("time",vendorData.getEstimateTime());
                intent.putExtra("image",vendorData.getPimagePath()+vendorData.getProfileImage());
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
            }
        });

        if (position==response.getPosition()){
            viewHolder.recyclerView.setLayoutManager(new LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false));
            viewHolder.recyclerView.setAdapter(new HomeHorizontalAdapter(response.getToprated_list(),context));
            viewHolder.recyclerView.setFocusable(false);
            viewHolder.layout.setVisibility(View.VISIBLE);
        }else {
            viewHolder.layout.setVisibility(View.GONE);
        }









    }

    @Override
    public int getItemCount() {
        return response.getVendor_data().size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView momImage;
        LinearLayout mainLayout;
        TextView address;
        TextView rating;
        TextView momTittle,time;
        LinearLayout layout;
        RecyclerView recyclerView;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            mainLayout=itemView.findViewById(R.id.mainLayout);
            layout=itemView.findViewById(R.id.layout);
            momImage=itemView.findViewById(R.id.momImage);
            momTittle=itemView.findViewById(R.id.momTittle);
            address=itemView.findViewById(R.id.address);
            time=itemView.findViewById(R.id.time);
            rating=itemView.findViewById(R.id.rating);
            recyclerView=itemView.findViewById(R.id.recyclerView);

        }
    }


    float  getEstimatedTime(Double lat,Double lon){
        int speedIs10MetersPerMinute = 10;
        float estimatedDriveTimeInMinutes = 0;
        Location location1 = new Location("");
        try {
            location1.setLatitude(FusedLocation.location.getLatitude());
            location1.setLongitude(FusedLocation.location.getLongitude());

            Location location2 = new Location("");
            location2.setLatitude(lat);
            location2.setLongitude(lon);
            float distanceInMeters = location1.distanceTo(location2);

           
            estimatedDriveTimeInMinutes = distanceInMeters / speedIs10MetersPerMinute;

        }catch (Exception e){
            e.printStackTrace();
        }
        
        return estimatedDriveTimeInMinutes;

    }

    String  getEstimatedTime2(Double lat,Double lon){

       String str= "http://maps.google.com/maps?saddr="+FusedLocation.location.getLatitude()+","+FusedLocation.location.getLongitude()+"&daddr="+lat+","+lon+"&ie=UTF8&0&om=0&output=kml";
        return str;

    }
}
