package mom.com.activities;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.PermissionChecker;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.google.firebase.FirebaseApp;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.iid.FirebaseInstanceId;

import java.util.ArrayList;
import java.util.List;

import mom.com.R;
import mom.com.helper.FusedLocation;
import mom.com.utils.Preferences;

public class SplashActivity extends AppCompatActivity {
    private final int SPLASH_DISPLAY_LENGTH = 2000;

    public static final int MULTIPLE_PERMISSIONS = 4;
    String[] permissions = new String[]{
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.CAMERA};

    ProgressDialog progressDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
//        Preferences.getInstance(this).setLogin(false);
        progressDialog=new ProgressDialog(this);
        progressDialog.setMessage("Getting location...");
        new FusedLocation(this);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            final int ACCESS_COARSE_LOCATION = PermissionChecker.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION);
            final int ACCESS_FINE_LOCATION = PermissionChecker.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION);
            final int WRITE_EXTERNAL_STORAGE = PermissionChecker.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE);
            final int READ_EXTERNAL_STORAGE = PermissionChecker.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE);
            final int CALL_PHONE = PermissionChecker.checkSelfPermission(this, Manifest.permission.CALL_PHONE);
            final int CAMERA = PermissionChecker.checkSelfPermission(this, Manifest.permission.CAMERA);
            if (ACCESS_COARSE_LOCATION == PermissionChecker.PERMISSION_GRANTED
                    && ACCESS_FINE_LOCATION == PermissionChecker.PERMISSION_GRANTED
                    && WRITE_EXTERNAL_STORAGE == PermissionChecker.PERMISSION_GRANTED
                    && READ_EXTERNAL_STORAGE == PermissionChecker.PERMISSION_GRANTED
                    && CALL_PHONE == PermissionChecker.PERMISSION_GRANTED
                    && CAMERA == PermissionChecker.PERMISSION_GRANTED) {
                launchActivity();
            } else {
                checkPermissions();
            }
        } else {
            launchActivity();
        }
    }


    private boolean checkPermissions() {
        int result;
        List<String> listPermissionsNeeded = new ArrayList<>();
        for (String p : permissions) {
            result = ContextCompat.checkSelfPermission(SplashActivity.this, p);
            if (result != PackageManager.PERMISSION_GRANTED) {
                listPermissionsNeeded.add(p);

            }
        }
        if (!listPermissionsNeeded.isEmpty()) {
            ActivityCompat.requestPermissions(this, listPermissionsNeeded.toArray(new String[listPermissionsNeeded.size()]), MULTIPLE_PERMISSIONS);
            return false;
        }
        return true;
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case MULTIPLE_PERMISSIONS: {
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    launchActivity();
                } else {
                    launchActivity();
                }
                return;
            }
        }
    }

    private void launchActivity() {


            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    try {
                        if (FusedLocation.location!=null){
                            progressDialog.dismiss();
                            launch();
                        }else {
                            if (!progressDialog.isShowing()){
                                progressDialog.show();
                            }
                            launchActivity();
                        }
                    }catch (Exception e){

                    }
                }
            }, 2000);

    }

    void launch(){
        if (Preferences.getInstance(getApplicationContext()).isLogin()) {
            Intent mainIntent = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(mainIntent);
            finish();
        }else {
            Intent mainIntent = new Intent(getApplicationContext(), HomePageActivity.class);
            startActivity(mainIntent);
            finish();
        }
    }
}
