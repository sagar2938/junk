package mom.com.activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions;
import com.bumptech.glide.request.RequestOptions;

import org.greenrobot.eventbus.Subscribe;

import java.util.HashMap;
import java.util.Map;

import mom.com.adapter.MomItemDetailAdapter;
import mom.com.R;
import mom.com.network.ApiCallService;
import mom.com.network.response.MomsItemListResponse;

public class MomItemDetailActivity extends BaseActivity {
RecyclerView recyclerView;
    LinearLayout view_cart;
    TextView name;
    TextView address;
    TextView time;
    TextView rating;
    TextView count;
    TextView amount;
    ImageView headerImage;
    Switch switchButton;
    public static MomItemDetailActivity context;
    MomItemDetailAdapter adapter;
    MomsItemListResponse response;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food_details);
        Toolbar toolbar=findViewById(R.id.toolbar_rest_details);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Food Details");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        name=findViewById(R.id.name);
        address=findViewById(R.id.address);
        time=findViewById(R.id.time);
        rating=findViewById(R.id.rating);
        count=findViewById(R.id.count);
        amount=findViewById(R.id.amount);
        headerImage=findViewById(R.id.headerImage);
        switchButton=findViewById(R.id.switchButton);
        context=this;
//        address.setText(Helper.getAddressText(this,new LatLng(FusedLocation.location.getLatitude(),FusedLocation.location.getLongitude())));

        Map map=new HashMap();
        map.put("mobile",getIntent().getStringExtra("mobile"));
        ApiCallService.action(MomItemDetailActivity.this,map,ApiCallService.Action.ACTION_GET_MENU);

        name.setText(getIntent().getStringExtra("name"));
        address.setText(getIntent().getStringExtra("address"));
        time.setText(getIntent().getStringExtra("time"));
        rating.setText(getIntent().getStringExtra("rating"));

        Glide.with(context)
                .load(getIntent().getStringExtra("image"))
                .transition(DrawableTransitionOptions.withCrossFade())
                .apply(RequestOptions.skipMemoryCacheOf(true))
                .apply(RequestOptions.diskCacheStrategyOf(DiskCacheStrategy.ALL))
                .apply(new RequestOptions().placeholder(R.drawable.default_food))
                .into(headerImage);


        recyclerView = findViewById(R.id.recyclerview);
        view_cart=findViewById(R.id.view_cart);
        view_cart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (count.getText().toString().trim().equals("0 Item")){
                    getDialog("Please add at least one item");
                    return;
                }
                Intent intent=new Intent(MomItemDetailActivity.this, CartActivity.class);
                intent.putExtra("name",getIntent().getStringExtra("name"));
                intent.putExtra("address",getIntent().getStringExtra("address"));
                intent.putExtra("image",getIntent().getStringExtra("image"));
                intent.putExtra("mobile",getIntent().getStringExtra("mobile"));
                startActivity(intent);
            }
        });


       /* switchButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                try {
                    if (isChecked){
                        MomsItemListResponse momsItemListResponse=response;
                        for (int i=0;i<momsItemListResponse.getMenuData().size();i++){
                            if (!momsItemListResponse.getMenuData().get(i).getFoodType().equals("Veg")){
                                momsItemListResponse.getMenuData().remove(i);
                            }
                        }
                        setAdapter(momsItemListResponse);
                    }else {
                        setAdapter(response);
                    }
                }catch (Exception e){

                }

            }
        });*/


    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        finish();
        return super.onOptionsItemSelected(item);
    }



    @Subscribe
    public void getMomItemList(MomsItemListResponse response){
        this.response=response;
        setAdapter(response);
    }


    void setAdapter(MomsItemListResponse response){
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        adapter = new MomItemDetailAdapter(response.getMenuData(),MomItemDetailActivity.this);
        recyclerView.setAdapter(adapter);
        recyclerView.setFocusable(false);
    }

    public void setAmount(String amt){
        amount.setText(amt);
    }
    public Double getAmount(){
        return Double.valueOf(amount.getText().toString());
    }


    public void setQuantity(Map<Integer,String> map){
        int i=0;
        for (Integer key : map.keySet()){
            Integer val= Integer.valueOf(map.get(key));
            i=i+val;
        }
        if (i<2){
            count.setText(""+i+" Item");
        }else {
            count.setText(""+i+" Items");
        }
    }


    @Override
    protected void onResume() {
        super.onResume();
        try {
            adapter.notifyDataSetChanged();
        }catch (Exception e){

        }
    }
}
