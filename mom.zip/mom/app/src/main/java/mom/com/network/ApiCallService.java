package mom.com.network;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.IntentService;
import android.content.DialogInterface;
import android.content.Intent;

import org.greenrobot.eventbus.EventBus;

import java.util.Map;

import mom.com.R;
import mom.com.model.CartMainModel;
import mom.com.network.response.LoginSignUpMainResponse;
import mom.com.network.response.LoginSignUpResponse;
import mom.com.network.response.MomListResponse;
import mom.com.network.response.MomListResponse2;
import mom.com.network.response.MomsItemListResponse;
import mom.com.network.response.OrderBookingResponse;
import mom.com.network.response.SucessResponse;
import mom.com.network.response.TokenResponse;
import mom.com.utils.CustomProgressDialog;
import mom.com.utils.Helper;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ApiCallService extends IntentService {

    static Object request;
    static Activity context;


    public ApiCallService() {
        super("ApiCallService");
    }


    public static void action(Activity ctx, String action) {
        Intent intent = new Intent(ctx, ApiCallService.class);
        intent.setAction(action);
        ctx.startService(intent);
        context = ctx;
    }


    public static void action(Activity ctx, Object request, String action) {
        context = ctx;
        if (!Helper.isNetworkAvailable(context)){
            getDialog(context,"No Internet","Please check your internet connection!!!",request,action);
            return;
        }
        CustomProgressDialog.getInstance(ctx).show();
        ApiCallService.request = request;
        Intent intent = new Intent(ctx, ApiCallService.class);
        intent.setAction(action);
        ctx.startService(intent);
    }

    class Local<T> implements Callback<T> {

        public void onResponse(Call<T> call, Response<T> response) {
            CustomProgressDialog.setDismiss();
            if (response.code() == 200) {
                T body = response.body();
                EventBus.getDefault().post(body);
            } else {
//                getDialog("Some thing went wrong!!! " + response.code());
                EventBus.getDefault().post("Some thing went wrong!!! " + response.code());
            }

        }

        public void onFailure(Call<T> call, Throwable t) {
            CustomProgressDialog.setDismiss();
            EventBus.getDefault().post(t.getMessage());
        }
    }



    public static void action2(Activity ctx, Object request, String action) {
        context = ctx;
        ApiCallService.request = request;
        Intent intent = new Intent(ctx, ApiCallService.class);
        intent.setAction(action);
        ctx.startService(intent);
    }


    public  class Local2<T> implements Callback<T> {

        @Override
        public void onResponse(Call<T> call, Response<T> response) {
            if (response.code() == 200) {
                T body = response.body();
                EventBus.getDefault().post(body);
            } else {
                EventBus.getDefault().post(ApiCallService.Action.ERROR + " " + response.code());
            }
        }

        @Override
        public void onFailure(Call<T> call, Throwable t) {
            EventBus.getDefault().post(t.getMessage());
        }
    }


    public interface Action{
        String ACTION_SIGN_IN="ACTION_SIGN_IN";
        String ACTION_SIGN_UP="ACTION_SIGN_UP";
        String ACTION_RESEND_OTP ="ACTION_RESEND_OTP";
        String ERROR = "Some thing went wrong";
        String DOCUMENT = "documents";
        String ACTION_SEND_OTP = "ACTION_SEND_OTP";
        String ACTION_SEND_TOKEN = "ACTION_SEND_TOKEN";
        String ACTION_MOM_LIST = "ACTION_MOM_LIST";
        String ACTION_GET_MENU = "ACTION_GET_MENU";
        String ACTION_MOM_LIST2 = "ACTION_MOM_LIST2";
        String ACTION_SUBMIT_ORDER = "ACTION_SUBMIT_ORDER";
        String ACTION_ADD_ADDRESS = "ACTION_ADD_ADDRESS";
    }

    protected void onHandleIntent(Intent intent) {
        String action = intent.getAction();
        Api api = ThisApp.getApi(this.getApplicationContext());
        if (action.equals(Action.ACTION_SIGN_IN)) {
            api.login((Map) request).enqueue(new Local<LoginSignUpMainResponse>());
        }else if (action.equals(Action.ACTION_SIGN_UP)) {
            api.signUp((Map) request).enqueue(new Local<LoginSignUpMainResponse>());
        }else if (action.equals(Action.ACTION_SEND_OTP)) {
            api.sendOtp((Map) request).enqueue(new Local<SucessResponse>());
        }else if (action.equals(Action.ACTION_RESEND_OTP)) {
            api.resendOtp((Map) request).enqueue(new Local<SucessResponse>());
        }else if (action.equals(Action.ACTION_SEND_TOKEN)) {
            api.sendToken((Map) request).enqueue(new Local<TokenResponse>());
        }else if (action.equals(Action.ACTION_MOM_LIST)) {
            api.getMomList((Map) request).enqueue(new Local<MomListResponse>());
        }else if (action.equals(Action.ACTION_MOM_LIST2)) {
            api.getMomList2((Map) request).enqueue(new Local<MomListResponse2>());
        }else if (action.equals(Action.ACTION_GET_MENU)) {
            api=ThisApp.getApi(this,"https://mom-apicalls.appspot.com");
            api.getMenu((Map) request).enqueue(new Local<MomsItemListResponse>());
        }else if (action.equals(Action.ACTION_SUBMIT_ORDER)) {
            api=ThisApp.getApi(this);
            api.submitOrder((CartMainModel) request).enqueue(new Local<OrderBookingResponse>());
        }else if (action.equals(Action.ACTION_ADD_ADDRESS)) {
//            api=ThisApp.getApi(this,"https://mom-apicalls.appspot.com/");
            api=ThisApp.getApi(this);
            api.addAddress((Map) request).enqueue(new Local<SucessResponse>());
        }
    }





    static void getDialog(final Activity context, String tittle, String message, final Object request, final String action) {
        new AlertDialog.Builder(context)
                .setTitle(tittle)
                .setMessage(message)
                .setCancelable(false)
                .setPositiveButton("Retry", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        ApiCallService.action(context,request,action);
                    }
                })
//                .setNegativeButton("Exit", null)
                .setIcon(R.drawable.ic_launcher_background)
                .show();
    }


    public void getDialog( String message) {
        new AlertDialog.Builder(this)
                .setTitle("Sorry")
                .setMessage(message)
                .setCancelable(true)
                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {

                    }
                })
//                .setNegativeButton("Cancel", null)
                .setIcon(R.mipmap.ic_launcher)
                .show();
    }

}

