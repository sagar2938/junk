package mom.com.WebService;

public class URLConstant {
    public static final String USER_ID_KEY = "userId_key";
    public static final String PASSWORD_KEY = "password";
    public static final String LOOGED_IN = "login";
    public static final String PREFERENCE_NAME = "com.example.Innobins.Vehicle_Management";
    public static final String EXIST_USER = "exist_user";
    public static final String EXIST_PASSWORD = "exist_pass";
    public static final String USER_NAME = "username";
    public static final String USER_EMAIL = "useremail";
    public static final String PHONE_NUMBER="phone";
    public static final String USER_ID = "userId";
    public static final String USER_ADDRESS="address";

}

