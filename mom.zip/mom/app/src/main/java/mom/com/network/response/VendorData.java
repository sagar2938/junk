package mom.com.network.response;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class VendorData {
    @SerializedName("awardImagePath")
    @Expose
    private String awardImagePath;
    @SerializedName("profileImage")
    @Expose
    private String profileImage;
    @SerializedName("skillName")
    @Expose
    private String skillName;
    @SerializedName("rating")
    @Expose
    private String rating;
    @SerializedName("bankName")
    @Expose
    private String bankName;
    @SerializedName("personalStatus")
    @Expose
    private Integer personalStatus;
    @SerializedName("parentName")
    @Expose
    private String parentName;
    @SerializedName("pincode")
    @Expose
    private String pincode;
    @SerializedName("pimagePath")
    @Expose
    private String pimagePath;
    @SerializedName("totalCall")
    @Expose
    private String totalCall;
    @SerializedName("documentStatus")
    @Expose
    private Integer documentStatus;
    @SerializedName("subscriptionAmount")
    @Expose
    private Integer subscriptionAmount;
    @SerializedName("updatedAt")
    @Expose
    private String updatedAt;
    @SerializedName("subscriptionDate")
    @Expose
    private String subscriptionDate;
    @SerializedName("partnerName")
    @Expose
    private String partnerName;
    @SerializedName("identityStatus")
    @Expose
    private Integer identityStatus;
    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("createdAt")
    @Expose
    private String createdAt;
    @SerializedName("licenseNo")
    @Expose
    private String licenseNo;
    @SerializedName("referalType")
    @Expose
    private String referalType;
    @SerializedName("locality")
    @Expose
    private String locality;
    @SerializedName("partnerReferal")
    @Expose
    private String partnerReferal;
    @SerializedName("state")
    @Expose
    private Object state;
    @SerializedName("bankIdType")
    @Expose
    private String bankIdType;
    @SerializedName("walletBalance")
    @Expose
    private Integer walletBalance;
    @SerializedName("longitude")
    @Expose
    private String longitude;
    @SerializedName("identityVerification")
    @Expose
    private Integer identityVerification;
    @SerializedName("latitude")
    @Expose
    private String latitude;
    @SerializedName("fcmToken")
    @Expose
    private String fcmToken;
    @SerializedName("status")
    @Expose
    private String status;
    @SerializedName("declarationStatus")
    @Expose
    private Integer declarationStatus;
    @SerializedName("accountNo")
    @Expose
    private String accountNo;
    @SerializedName("city")
    @Expose
    private Object city;
    @SerializedName("backImage")
    @Expose
    private String backImage;
    @SerializedName("ifsc")
    @Expose
    private String ifsc;
    @SerializedName("idNumber")
    @Expose
    private String idNumber;
    @SerializedName("licenseStatus")
    @Expose
    private Integer licenseStatus;
    @SerializedName("referalCode")
    @Expose
    private String referalCode;
    @SerializedName("houseNo")
    @Expose
    private String houseNo;
    @SerializedName("declaration")
    @Expose
    private String declaration;
    @SerializedName("awardImage")
    @Expose
    private String awardImage;
    @SerializedName("bankImageName")
    @Expose
    private String bankImageName;
    @SerializedName("idType")
    @Expose
    private String idType;
    @SerializedName("name")
    @Expose
    private String name;
    @SerializedName("mobile")
    @Expose
    private String mobile;
    @SerializedName("bankStatus")
    @Expose
    private Integer bankStatus;
    @SerializedName("frontImage")
    @Expose
    private String frontImage;
    @SerializedName("dob")
    @Expose
    private String dob;
    @SerializedName("licenseName")
    @Expose
    private String licenseName;
    @SerializedName("licenceImage")
    @Expose
    private String licenceImage;
    @SerializedName("partnerType")
    @Expose
    private String partnerType;
    @SerializedName("awardStatus")
    @Expose
    private Integer awardStatus;

    @SerializedName("estimateTime")
    @Expose
    private Integer estimateTime;

    public String getAwardImagePath() {
        return awardImagePath;
    }

    public void setAwardImagePath(String awardImagePath) {
        this.awardImagePath = awardImagePath;
    }

    public String getProfileImage() {
        return profileImage;
    }

    public void setProfileImage(String profileImage) {
        this.profileImage = profileImage;
    }

    public String getSkillName() {
        return skillName;
    }

    public void setSkillName(String skillName) {
        this.skillName = skillName;
    }

    public String getRating() {
        return rating;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    public Integer getPersonalStatus() {
        return personalStatus;
    }

    public void setPersonalStatus(Integer personalStatus) {
        this.personalStatus = personalStatus;
    }

    public String getParentName() {
        return parentName;
    }

    public void setParentName(String parentName) {
        this.parentName = parentName;
    }

    public String getPincode() {
        return pincode;
    }

    public void setPincode(String pincode) {
        this.pincode = pincode;
    }

    public String getPimagePath() {
        return pimagePath;
    }

    public void setPimagePath(String pimagePath) {
        this.pimagePath = pimagePath;
    }

    public String getTotalCall() {
        return totalCall;
    }

    public void setTotalCall(String totalCall) {
        this.totalCall = totalCall;
    }

    public Integer getDocumentStatus() {
        return documentStatus;
    }

    public void setDocumentStatus(Integer documentStatus) {
        this.documentStatus = documentStatus;
    }

    public Integer getSubscriptionAmount() {
        return subscriptionAmount;
    }

    public void setSubscriptionAmount(Integer subscriptionAmount) {
        this.subscriptionAmount = subscriptionAmount;
    }

    public String getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getSubscriptionDate() {
        return subscriptionDate;
    }

    public void setSubscriptionDate(String subscriptionDate) {
        this.subscriptionDate = subscriptionDate;
    }

    public String getPartnerName() {
        return partnerName;
    }

    public void setPartnerName(String partnerName) {
        this.partnerName = partnerName;
    }

    public Integer getIdentityStatus() {
        return identityStatus;
    }

    public void setIdentityStatus(Integer identityStatus) {
        this.identityStatus = identityStatus;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public String getLicenseNo() {
        return licenseNo;
    }

    public void setLicenseNo(String licenseNo) {
        this.licenseNo = licenseNo;
    }

    public String getReferalType() {
        return referalType;
    }

    public void setReferalType(String referalType) {
        this.referalType = referalType;
    }

    public String getLocality() {
        return locality;
    }

    public void setLocality(String locality) {
        this.locality = locality;
    }

    public String getPartnerReferal() {
        return partnerReferal;
    }

    public void setPartnerReferal(String partnerReferal) {
        this.partnerReferal = partnerReferal;
    }

    public Object getState() {
        return state;
    }

    public void setState(Object state) {
        this.state = state;
    }

    public String getBankIdType() {
        return bankIdType;
    }

    public void setBankIdType(String bankIdType) {
        this.bankIdType = bankIdType;
    }

    public Integer getWalletBalance() {
        return walletBalance;
    }

    public void setWalletBalance(Integer walletBalance) {
        this.walletBalance = walletBalance;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public Integer getIdentityVerification() {
        return identityVerification;
    }

    public void setIdentityVerification(Integer identityVerification) {
        this.identityVerification = identityVerification;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getFcmToken() {
        return fcmToken;
    }

    public void setFcmToken(String fcmToken) {
        this.fcmToken = fcmToken;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Integer getDeclarationStatus() {
        return declarationStatus;
    }

    public void setDeclarationStatus(Integer declarationStatus) {
        this.declarationStatus = declarationStatus;
    }

    public String getAccountNo() {
        return accountNo;
    }

    public void setAccountNo(String accountNo) {
        this.accountNo = accountNo;
    }

    public Object getCity() {
        return city;
    }

    public void setCity(Object city) {
        this.city = city;
    }

    public String getBackImage() {
        return backImage;
    }

    public void setBackImage(String backImage) {
        this.backImage = backImage;
    }

    public String getIfsc() {
        return ifsc;
    }

    public void setIfsc(String ifsc) {
        this.ifsc = ifsc;
    }

    public String getIdNumber() {
        return idNumber;
    }

    public void setIdNumber(String idNumber) {
        this.idNumber = idNumber;
    }

    public Integer getLicenseStatus() {
        return licenseStatus;
    }

    public void setLicenseStatus(Integer licenseStatus) {
        this.licenseStatus = licenseStatus;
    }

    public String getReferalCode() {
        return referalCode;
    }

    public void setReferalCode(String referalCode) {
        this.referalCode = referalCode;
    }

    public String getHouseNo() {
        return houseNo;
    }

    public void setHouseNo(String houseNo) {
        this.houseNo = houseNo;
    }

    public String getDeclaration() {
        return declaration;
    }

    public void setDeclaration(String declaration) {
        this.declaration = declaration;
    }

    public String getAwardImage() {
        return awardImage;
    }

    public void setAwardImage(String awardImage) {
        this.awardImage = awardImage;
    }

    public String getBankImageName() {
        return bankImageName;
    }

    public void setBankImageName(String bankImageName) {
        this.bankImageName = bankImageName;
    }

    public String getIdType() {
        return idType;
    }

    public void setIdType(String idType) {
        this.idType = idType;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public Integer getBankStatus() {
        return bankStatus;
    }

    public void setBankStatus(Integer bankStatus) {
        this.bankStatus = bankStatus;
    }

    public String getFrontImage() {
        return frontImage;
    }

    public void setFrontImage(String frontImage) {
        this.frontImage = frontImage;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getLicenseName() {
        return licenseName;
    }

    public void setLicenseName(String licenseName) {
        this.licenseName = licenseName;
    }

    public String getLicenceImage() {
        return licenceImage;
    }

    public void setLicenceImage(String licenceImage) {
        this.licenceImage = licenceImage;
    }

    public String getPartnerType() {
        return partnerType;
    }

    public void setPartnerType(String partnerType) {
        this.partnerType = partnerType;
    }

    public Integer getAwardStatus() {
        return awardStatus;
    }

    public void setAwardStatus(Integer awardStatus) {
        this.awardStatus = awardStatus;
    }

    public Integer getEstimateTime() {
        return estimateTime;
    }

    public void setEstimateTime(Integer estimateTime) {
        this.estimateTime = estimateTime;
    }
}
